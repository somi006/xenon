<?php
include_once 'config.php';

header("Location: index.php");