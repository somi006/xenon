<?php
session_start();
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "xenon_assign";

// Create connection
$conn = mysqli_connect($serverName, $userName, $password, $dbName);

// Check connection
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// echo "Connected successfully";
